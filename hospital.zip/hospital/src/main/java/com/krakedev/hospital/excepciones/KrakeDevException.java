package com.krakedev.hospital.excepciones;

public class KrakeDevException extends Exception{

	public KrakeDevException(String mensaje) {
		
		super(mensaje);
	}
}
