package com.krakedev.inventarios.excepciones;

public class KrakeDevException extends Exception{

	public KrakeDevException(String mensaje) {
		
		super(mensaje);
	}
}
